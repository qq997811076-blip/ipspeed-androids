# IP 测速 App（内置 Termux 运行时 + Go 核心）

这个版本按“Termux 是核心，App 是自定义界面”的方向设计。它不调用手机上另行安装的 Termux，也不把 Go 测速逻辑重写成 Kotlin 网络代码。

## 当前工程结构

- `app/src/main/java/.../MainActivity.kt`：中文深色绿色 UI、参数/IP/历史编辑、结果筛选与复制。
- `app/src/main/assets/myspeed_app.go`：Go 测速核心源码，保留 HTTPS/443、强制连接候选 IP、Range 请求和并发测速；增加 `APP_*` 机器可读输出以便 UI 更新进度。
- `app/src/main/assets/sss.android-arm64`：由上述 Go 源码交叉编译的 Android ARM64 可执行文件。
- `app/src/main/assets/sss.android-arm64.b64`：用于把可执行文件写入内置运行环境 HOME 的 Base64 载荷。
- `libtermux-android`：用于在 App 私有目录初始化隔离的 Termux 运行环境，不需要另装 Termux。

## 首次启动行为

首次启动时，嵌入式运行时 SDK 会从网络下载并初始化它的 bootstrap（项目文档描述约 30 MB），随后 App 把 Go 核心放进运行时 HOME。后续测速不需要在手机里单独安装 Go，也不会改动其他 Termux 安装或其文件。

**说明：** 这版采用的是实验阶段的 `libtermux-android` SDK，且运行时 bootstrap 首次启动时下载。因此它是“App 内私有运行环境”，不是完全离线、所有运行时文件都预先塞进 APK 的安装包。该 SDK 公开文档明确标注实验阶段，需要实际设备验证。

## 构建

用 Android Studio 打开 `SpeedTestAndroid` 文件夹，安装 JDK 17 和 Android SDK Platform 35，等待 Gradle 下载依赖后执行 `assembleDebug`。

依赖：Android Gradle Plugin 8.7.3、Kotlin 2.0.21、`com.github.libtermux:libtermux-android:1.0.0`（JitPack）。本运行时 SDK 的 API/依赖解析需要在线完成。

## 重要验证事项

- 本工作环境没有 Android SDK / Gradle，因此这里无法实际构建或安装验证 APK；不要把本 ZIP 当作已验证 APK。
- Go 核心当前针对 Android `arm64` 编译，适合绝大多数近年的 Android 手机；非 ARM64 设备需要增加对应 ABI 构建。
- Go 代码保留 `InsecureSkipVerify: true` 的原始行为，会跳过 TLS 证书验证，存在安全风险。
- 测速 URL 需要 HTTPS；实际目标地址、候选 IP 与网络环境会影响结果。

## 在云端生成 APK（可选）

工程带有 `.github/workflows/build-apk.yml`。把整个目录上传到 GitHub 仓库后，在仓库的 **Actions** 页面运行 **Build Android APK**，成功后下载名为 `IP-Speed-Test-debug-apk` 的 artifact。该流程仍需在线解析 JitPack 依赖；如果 SDK 依赖解析失败，需要先修复依赖版本再构建。
