package com.example.ipspeed

import android.app.Activity
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.libtermux.LibTermux
import com.libtermux.LogLevel
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import javax.net.ssl.*
import java.net.*
import java.io.*
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class MainActivity : Activity() {
    private val bg = Color.rgb(17, 22, 27)
    private val panel = Color.rgb(29, 36, 42)
    private val green = Color.rgb(65, 220, 145)
    private val white = Color.rgb(235, 241, 245)
    private val muted = Color.rgb(157, 171, 180)
    private lateinit var root: LinearLayout
    private lateinit var urlInput: EditText
    private lateinit var durationInput: EditText
    private lateinit var concurrencyInput: EditText
    private lateinit var thresholdInput: EditText
    private lateinit var status: TextView
    private lateinit var resultBox: LinearLayout
    private lateinit var resultScroll: ScrollView
    private var allResults = mutableListOf<Result>()
    private var ipList = mutableListOf<String>()
    private var completed = 0
    private var succeeded = 0
    private var failed = 0
    private var total = 0
    private var isRunning = false
    private val cancelled = AtomicBoolean(false)
    private var executor: ExecutorService? = null
    @Volatile private var runtimeReady = false
    @Volatile private var runtimeInitializing = false
    private lateinit var termux: LibTermux
    private var processedLogLines = 0
    private val uiHandler = Handler(Looper.getMainLooper())
    private var runSnapshot = RunConfig("https://example.com/", 10, 10)
    private val prefs by lazy { getSharedPreferences("speedtest", MODE_PRIVATE) }
    private data class Result(val ip: String, val speed: Double)
    private data class RunConfig(val url: String, val seconds: Int, val concurrency: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadFiles()
        showMain()
        initializeEmbeddedTermux()
    }

    private fun loadFiles() {
        ipList = readText("ips.txt").lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.distinct().toMutableList()
        urlInputValue = prefs.getString("url", "https://example.com/") ?: "https://example.com/"
        durationValue = prefs.getString("duration", "10") ?: "10"
        concurrencyValue = prefs.getString("concurrency", "10") ?: "10"
        thresholdValue = prefs.getString("threshold", "0.5") ?: "0.5"
    }
    private var urlInputValue = "https://example.com/"
    private var durationValue = "10"
    private var concurrencyValue = "10"
    private var thresholdValue = "0.5"
    private fun readText(name: String): String = try { openFileInput(name).bufferedReader().use { it.readText() } } catch (_: Exception) { "" }
    private fun writeText(name: String, text: String) { openFileOutput(name, MODE_PRIVATE).bufferedWriter().use { it.write(text) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun label(text: String, size: Float = 14f, color: Int = white): TextView = TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }
    private fun field(hint: String, value: String, numeric: Boolean = false): EditText = EditText(this).apply {
        setSingleLine(true); setText(value); this.hint = hint; setHintTextColor(muted); setTextColor(white); textSize = 14f
        setPadding(dp(10), 0, dp(10), 0); setBackgroundColor(panel)
        if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        layoutParams = LinearLayout.LayoutParams(-1, dp(44))
    }
    private fun button(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; setTextColor(bg); setBackgroundColor(green); textSize = 12f; isAllCaps = false
        setOnClickListener { onClick() }
    }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun space(h: Int = 8) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun addLabelled(parent: LinearLayout, title: String, edit: EditText) {
        parent.addView(label(title, 12f, muted)); parent.addView(space(3)); parent.addView(edit); parent.addView(space(8))
    }
    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); setBackgroundColor(bg) }
        root.addView(label(title, 22f, green).apply { typeface = Typeface.DEFAULT_BOLD }); root.addView(space(8)); setContentView(root); return root
    }

    private fun showMain() {
        val page = base("IP 测速")
        val top = row(); top.addView(button("编辑 IP 列表") { showEditor(false) }, LinearLayout.LayoutParams(0, dp(44), 1f)); top.addView(spaceW(8)); top.addView(button("停止测速") { stopRun() }, LinearLayout.LayoutParams(0, dp(44), 1f)); page.addView(top); page.addView(space(10))
        urlInput = field("例如 https://example.com/file", urlInputValue); addLabelled(page, "测速 URL", urlInput)
        val r1 = row(); val c1 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; val c2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c1.addView(label("测速时长（秒）", 12f, muted)); durationInput = field("秒数", durationValue, true); c1.addView(durationInput)
        c2.addView(label("并发数", 12f, muted)); concurrencyInput = field("并发数", concurrencyValue, true); c2.addView(concurrencyInput)
        r1.addView(c1, LinearLayout.LayoutParams(0, -2, 1f)); r1.addView(spaceW(8)); r1.addView(c2, LinearLayout.LayoutParams(0, -2, 1f)); page.addView(r1); page.addView(space(8))
        addLabelled(page, "最低显示速度（MB/s，可输入小数）", fieldPlaceholderThreshold().also { thresholdInput = it })
        page.addView(button("开始测速") { startRun() }, LinearLayout.LayoutParams(-1, dp(44))); page.addView(space(8))
        status = label(if (runtimeReady) "内置运行环境已就绪" else "正在准备内置运行环境…", 12f, muted); page.addView(status); page.addView(space(6))
        val resultTools = row(); resultTools.addView(label("测速结果（速度降序）", 14f, white), LinearLayout.LayoutParams(0, -2, 1f)); resultTools.addView(button("历史结果") { showEditor(true) }); resultTools.addView(spaceW(4)); resultTools.addView(button("复制当前结果") { copyCurrent() }); page.addView(resultTools); page.addView(space(4))
        resultScroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(panel); overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS }
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }; resultScroll.addView(resultBox)
        page.addView(resultScroll, LinearLayout.LayoutParams(-1, 0, 1f)); renderResults()
        thresholdInput.addTextChangedListener(SimpleWatcher { renderResults() })
    }
    private fun fieldPlaceholderThreshold() = field("0.5", thresholdValue, true)
    private fun spaceW(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }

    private fun initializeEmbeddedTermux() {
        if (runtimeReady || runtimeInitializing) return
        if (Build.SUPPORTED_ABIS.none { it == "arm64-v8a" }) {
            if (::status.isInitialized) status.text = "当前设备不是 ARM64，暂不支持此预编译核心"
            toast("当前版本只包含 ARM64 Go 核心")
            return
        }
        runtimeInitializing = true
        if (::status.isInitialized) status.text = "首次启动正在初始化内置 Termux 环境，请保持网络连接…"
        Thread {
            try {
                termux = LibTermux.builder(this)
                    .autoInstall(true)
                    .logLevel(LogLevel.DEBUG)
                    .build()
                termux.initializeBlocking()
                val b64 = assets.open("sss.android-arm64.b64").bufferedReader().use { it.readText() }
                termux.bridge.writeFile("sss.android-arm64.b64", b64)
                val result = termux.bridge.run("cd \"\$HOME\" && base64 -d sss.android-arm64.b64 > sss && chmod 700 sss && rm -f sss.android-arm64.b64 && echo RUNTIME_READY")
                if (!result.stdout.contains("RUNTIME_READY")) throw IllegalStateException("内置测速核心部署失败：${result.stdout} ${result.stderr}")
                runtimeReady = true
                runOnUiThread { if (::status.isInitialized) status.text = "内置 Termux 环境已就绪" }
            } catch (e: Exception) {
                runOnUiThread {
                    if (::status.isInitialized) status.text = "内置环境初始化失败：${e.message ?: "未知错误"}"
                    toast("内置环境初始化失败，请检查网络后重启 App")
                }
            } finally { runtimeInitializing = false }
        }.start()
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    private fun startRun() {
        if (!runtimeReady) { toast(if (runtimeInitializing) "内置 Termux 环境仍在初始化" else "内置环境未就绪，请重新打开 App"); if (!runtimeInitializing) initializeEmbeddedTermux(); return }
        if (isRunning) { toast("测速正在进行"); return }
        val url = urlInput.text.toString().trim()
        val seconds = durationInput.text.toString().toIntOrNull() ?: 0
        val concurrency = concurrencyInput.text.toString().toIntOrNull() ?: 0
        if (url.isBlank() || seconds <= 0 || concurrency <= 0) { toast("请填写有效 URL、正整数秒数和并发数"); return }
        try { val u = URL(url); if (u.protocol != "https") { toast("原测速逻辑仅支持 HTTPS/443"); return } } catch (_: Exception) { toast("URL 格式不正确"); return }
        savePrefs()
        ipList = readText("ips.txt").lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.distinct().toMutableList()
        if (ipList.isEmpty()) { toast("请先在‘编辑 IP 列表’中保存 IP"); return }
        runSnapshot = RunConfig(url, seconds, concurrency)
        allResults.clear(); completed = 0; succeeded = 0; failed = 0; total = ipList.size
        processedLogLines = 0; cancelled.set(false); isRunning = true
        status.text = "正在启动 Go 测速核心…"; renderResults()
        Thread {
            try {
                termux.bridge.writeFile("ips.txt", ipList.joinToString("\n", postfix = "\n"))
                termux.bridge.run("cd \"\$HOME\"; rm -f app.log app.pid; (exec ./sss ${shellQuote(url)} $seconds $concurrency > \"\$HOME/app.log\" 2>&1 < /dev/null) & echo \$! > \"\$HOME/app.pid\"")
                runOnUiThread { status.text = "测速中 0/$total | 成功 0 | 失败 0 | 符合门槛 0"; uiHandler.post(pollLogRunnable) }
            } catch (e: Exception) {
                runOnUiThread { isRunning = false; status.text = "启动失败：${e.message}"; toast("启动 Go 测速失败") }
            }
        }.start()
    }

    private val pollLogRunnable = object : Runnable {
        override fun run() {
            if (!runtimeReady || !isRunning) return
            Thread {
                val log = try { termux.bridge.readFile("app.log") } catch (_: Exception) { "" }
                runOnUiThread {
                    consumeRuntimeLog(log)
                    if (isRunning) uiHandler.postDelayed(this, 700)
                }
            }.start()
        }
    }

    private fun consumeRuntimeLog(log: String) {
        val completeLog = log.substringBeforeLast('\n', "")
        val lines = if (completeLog.isEmpty()) emptyList() else completeLog.split('\n')
        if (processedLogLines > lines.size) processedLogLines = 0
        for (i in processedLogLines until lines.size) {
            val line = lines[i].trim()
            if (line.isEmpty()) continue
            val p = line.split('|')
            when (p.firstOrNull()) {
                "APP_RESULT" -> if (p.size >= 3) {
                    val speed = p[2].toDoubleOrNull()
                    if (speed != null && allResults.none { it.ip == p[1] }) {
                        allResults.add(Result(p[1], speed))
                        succeeded = allResults.size
                        if (speed >= 0.5) appendHistory(p[1], speed)
                    }
                }
                "APP_PROGRESS" -> if (p.size >= 5) {
                    completed = p[1].toIntOrNull() ?: completed
                    total = p[2].toIntOrNull() ?: total
                    succeeded = p[3].toIntOrNull() ?: succeeded
                    failed = p[4].toIntOrNull() ?: failed
                }
                "APP_FAIL" -> failed++
                "APP_ERROR" -> { status.text = line.substringAfter("APP_ERROR|"); isRunning = false }
                "APP_DONE" -> {
                    if (p.size >= 4) { completed = p[1].toIntOrNull() ?: completed; succeeded = p[2].toIntOrNull() ?: succeeded; failed = p[3].toIntOrNull() ?: failed }
                    isRunning = false
                }
            }
        }
        processedLogLines = lines.size
        if (isRunning) status.text = "测速中 $completed/$total | 成功 $succeeded | 失败 $failed | 符合门槛 ${filteredResults().size}"
        else if (status.text.toString().startsWith("启动失败") || status.text.toString().startsWith("读取") || status.text.toString().startsWith("参数")) { /* keep error */ }
        else status.text = "${if (cancelled.get()) "已停止" else "测速完成"} $completed/$total | 成功 $succeeded | 失败 $failed | 符合门槛 ${filteredResults().size}"
        renderResults()
    }

    private fun finishIfDone() { if (completed >= total || cancelled.get()) { isRunning = false; status.text = "${if (cancelled.get()) "已停止" else "测速完成"} $completed/$total | 成功 $succeeded | 失败 $failed | 符合门槛 ${filteredResults().size}"; renderResults() } }
    private fun stopRun() {
        if (!isRunning) { toast("当前没有正在运行的测速"); return }
        cancelled.set(true)
        status.text = "正在停止测速…"
        Thread { try { termux.bridge.run("if [ -f \"\$HOME/app.pid\" ]; then kill -TERM \$(cat \"\$HOME/app.pid\") 2>/dev/null || true; fi") } catch (_: Exception) {} }.start()
    }
    private fun savePrefs() { urlInputValue = urlInput.text.toString(); durationValue = durationInput.text.toString(); concurrencyValue = concurrencyInput.text.toString(); thresholdValue = thresholdInput.text.toString(); prefs.edit().putString("url", urlInputValue).putString("duration", durationValue).putString("concurrency", concurrencyValue).putString("threshold", thresholdValue).apply() }
    private fun threshold(): Double = thresholdInput.text.toString().toDoubleOrNull() ?: 0.5
    private fun filteredResults(): List<Result> = allResults.filter { it.speed >= threshold() }.sortedByDescending { it.speed }
    private fun renderResults() {
        if (!::resultBox.isInitialized) return
        resultBox.removeAllViews()
        val sorted = filteredResults(); val shown = if (isRunning) sorted.take(10) else sorted
        if (shown.isEmpty()) resultBox.addView(label("暂无符合门槛的结果", 13f, muted).apply { setPadding(0, dp(8), 0, dp(8)) })
        shown.forEach { result ->
            val line = row().apply { setPadding(0, dp(3), 0, dp(3)) }
            val txt = label("${result.ip}#${"%.2f".format(java.util.Locale.US, result.speed)} MB/s", 13f, white)
            txt.setOnLongClickListener { copyText(result.ip); true }; line.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            val cp = label("复制", 12f, green).apply { setPadding(dp(8), dp(6), dp(4), dp(6)); setOnClickListener { copyText("${result.ip}#${"%.2f".format(java.util.Locale.US, result.speed)} MB/s") } }
            line.addView(cp); resultBox.addView(line)
        }
        if (isRunning && sorted.size > 10) resultBox.addView(label("测速中仅显示前 10 名；当前符合门槛共 ${sorted.size} 个", 11f, muted))
    }
    private fun copyCurrent() { val text = filteredResults().joinToString("\n") { "${it.ip}#${"%.2f".format(java.util.Locale.US, it.speed)} MB/s" }; if (text.isBlank()) toast("当前没有可复制结果") else copyText(text) }
    private fun copyText(text: String) { val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager; cb.setPrimaryClip(ClipData.newPlainText("测速结果", text)); toast("已复制") }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun showEditor(history: Boolean) {
        savePrefsIfMain(); val filename = if (history) "history.txt" else "ips.txt"
        if (history && !readText(filename).isBlank()) { /* loaded below */ }
        val page = base(if (history) "历史结果" else "编辑 IP 列表")
        val bar = row(); bar.addView(button("返回") { showMain() }, LinearLayout.LayoutParams(0, dp(44), 1f)); bar.addView(spaceW(8)); bar.addView(button("保存") {
            val raw = editor?.text?.toString() ?: ""
            if (history) {
                val parsed = raw.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.distinct().mapNotNull { parseHistory(it) }.sortedByDescending { it.second }
                writeText("history.txt", parsed.joinToString("\n") { "${it.first}#${"%.2f".format(java.util.Locale.US, it.second)} MB/s" })
            } else {
                writeText("ips.txt", raw.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.distinct().joinToString("\n"))
            }
            toast("已保存"); showMain()
        }, LinearLayout.LayoutParams(0, dp(44), 1f)); page.addView(bar); page.addView(space(8))
        editor = EditText(this).apply { setTextColor(white); setHintTextColor(muted); textSize = 14f; gravity = Gravity.TOP or Gravity.START; setPadding(dp(10), dp(10), dp(10), dp(10)); setBackgroundColor(panel); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS; setHorizontallyScrolling(false); hint = if (history) "每行一个 IP#速度" else "每行一个 IP"; setText(readText(filename)) }
        page.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    private var editor: EditText? = null
    private fun savePrefsIfMain() { if (::urlInput.isInitialized && ::durationInput.isInitialized && ::concurrencyInput.isInitialized && ::thresholdInput.isInitialized) savePrefs() }
    private fun parseHistory(line: String): Pair<String, Double>? { val p = line.split("#", limit = 2); if (p.size != 2) return null; val ip = p[0].trim(); val speed = p[1].trim().substringBefore(" ").toDoubleOrNull() ?: return null; return if (ip.isNotEmpty() && speed >= 0.5) ip to speed else null }
    @Synchronized private fun appendHistory(ip: String, speed: Double) {
        val rows = readText("history.txt").lineSequence().mapNotNull { parseHistory(it) }.toMutableList()
        rows.add(ip to speed)
        val normalized = rows.sortedByDescending { it.second }.joinToString("\n") { "${it.first}#${"%.2f".format(java.util.Locale.US, it.second)} MB/s" }
        writeText("history.txt", normalized)
    }

    // 网络测速由 assets 中编译好的 Go 核心在内置 Termux 运行环境中执行；Kotlin 仅负责界面和结果展示。

}

private class SimpleWatcher(val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
