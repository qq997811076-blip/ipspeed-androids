package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
)

type result struct { ip string; speed float64 }
var outputMu sync.Mutex
func out(format string, args ...any) { outputMu.Lock(); defer outputMu.Unlock(); fmt.Printf(format+"\n", args...) }

func main() {
 if len(os.Args) != 4 { out("APP_ERROR|用法：sss URL 秒数 并发数"); os.Exit(2) }
 target := strings.TrimSpace(os.Args[1])
 seconds, err1 := strconv.Atoi(os.Args[2]); concurrency, err2 := strconv.Atoi(os.Args[3])
 parsed, errURL := url.Parse(target)
 if err1 != nil || seconds <= 0 || err2 != nil || concurrency <= 0 || errURL != nil || parsed.Scheme != "https" || parsed.Hostname() == "" { out("APP_ERROR|参数无效：URL 必须是 HTTPS，秒数和并发数必须为正整数"); os.Exit(2) }
 f, err := os.Open("ips.txt"); if err != nil { out("APP_ERROR|读取 ips.txt 失败：%v", err); os.Exit(2) }; defer f.Close()
 scan := bufio.NewScanner(f); ips := []string{}; seen := map[string]bool{}
 for scan.Scan() { ip := strings.TrimSpace(scan.Text()); if ip != "" && !seen[ip] { ips = append(ips, ip); seen[ip] = true } }
 if scan.Err() != nil { out("APP_ERROR|读取 IP 列表异常：%v", scan.Err()); os.Exit(2) }
 if len(ips)==0 { out("APP_ERROR|IP 列表为空"); os.Exit(2) }
 total := len(ips); out("APP_READY|%d", total)
 rootCtx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM); defer cancel()
 sem := make(chan struct{}, concurrency); var wg sync.WaitGroup; var done, success, failed atomic.Int64
 results := make([]result, 0, total); var resultMu sync.Mutex
 transportBase := &http.Transport{TLSClientConfig:&tls.Config{InsecureSkipVerify:true}, MaxIdleConns:concurrency*2, IdleConnTimeout:30*time.Second, DisableCompression:true}
 test := func(ip string) (float64, error) {
  ctx, stop := context.WithTimeout(rootCtx, time.Duration(seconds+6)*time.Second); defer stop()
  tr := transportBase.Clone(); tr.DialContext = func(c context.Context, network, addr string) (net.Conn,error) { d:=net.Dialer{Timeout:5*time.Second}; return d.DialContext(c,"tcp",net.JoinHostPort(ip,"443")) }
  client := &http.Client{Timeout:time.Duration(seconds+6)*time.Second, Transport:tr}
  req,e:=http.NewRequestWithContext(ctx,"GET",target,nil); if e!=nil{return 0,e}
  req.Header.Set("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"); req.Header.Set("Range","bytes=0-104857600")
  resp,e:=client.Do(req); if e!=nil{return 0,e}; defer resp.Body.Close()
  start:=time.Now(); var bytes int64; buf:=make([]byte,4096)
  for time.Since(start)<time.Duration(seconds)*time.Second && rootCtx.Err()==nil { n,re:=resp.Body.Read(buf); if n>0 { bytes+=int64(n) }; if re!=nil { break } }
  elapsed:=time.Since(start).Seconds(); if elapsed<=0{return 0,fmt.Errorf("time invalid")}; return float64(bytes)/elapsed/1024/1024,nil
 }
 for _, ip := range ips { if rootCtx.Err()!=nil { break }; sem<-struct{}{}; wg.Add(1); go func(ip string){ defer func(){<-sem; wg.Done(); d:=done.Add(1); out("APP_PROGRESS|%d|%d|%d|%d",d,total,success.Load(),failed.Load()) }(); speed,e:=test(ip); if e!=nil { failed.Add(1); out("APP_FAIL|%s|%s",ip,strings.ReplaceAll(e.Error(),"|","/")); return }; success.Add(1); r:=result{ip:ip,speed:speed}; resultMu.Lock(); results=append(results,r); resultMu.Unlock(); out("APP_RESULT|%s|%.4f",ip,speed) }(ip) }
 wg.Wait(); resultMu.Lock(); sort.Slice(results,func(i,j int)bool{return results[i].speed>results[j].speed}); resultMu.Unlock()
 out("APP_DONE|%d|%d|%d|%t",done.Load(),success.Load(),failed.Load(),rootCtx.Err()!=nil)
}
