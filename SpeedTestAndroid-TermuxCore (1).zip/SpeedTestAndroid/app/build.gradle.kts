plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ipspeed"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.ipspeed"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0-termux-core"
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    // Experimental embedded Termux runtime; no separate Termux app is required.
    implementation("com.github.libtermux:libtermux-android:1.0.0")
}
